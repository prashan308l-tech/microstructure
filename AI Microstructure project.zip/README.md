# Microstructure Classifier (steel families)

Classifies a light-optical micrograph as Austenitic Stainless, Carbon, or Duplex Stainless steel.
Runs fully in the browser; the trained model is embedded in one HTML file.

## Files
- train.py      : builds patch features, runs 5-fold image-level CV, trains and writes model.json
- lib.js        : feature extraction + prediction in JavaScript (must match train.py exactly)
- parity.py     : checks that lib.js and train.py give identical features/probabilities (needs node)
- gen.py        : embeds model.json + lib.js into microstructure-classifier.html
- model.json    : trained weights (CV accuracy ~0.967)
- microstructure-classifier.html : the finished website (open in any browser)

## Run
    pip install -r requirements.txt
    git clone -b main-pages --depth 1 https://github.com/Yamina77/Microst.Images_MetallicMaterialsDataset.git d
    python train.py        # trains, prints CV accuracy, writes model.json
    python parity.py && node t.js   # optional sanity check
    python gen.py          # writes microstructure-classifier.html

Host the HTML on GitHub Pages, Netlify, or any static server.
If you change feature code, change it in BOTH train.py and lib.js, then re-run parity check.
